<?php
    $conn=mysqli_connect("localhost","root","","web_animes");
    mysqli_set_charset($conn,"utf8");
?>